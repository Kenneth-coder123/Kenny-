function coderMessage() {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const codage = "BFGKXIZMTUPNQRAWYDJCLESHVO";
  let texte = document.getElementById("inputMessage").value;
  let resultat = "";

  for (let i = 0; i < texte.length; i++) {
    let char = texte[i];
    let isLower = char === char.toLowerCase();
    let upperChar = char.toUpperCase();

    if (alphabet.includes(upperChar)) {
      let index = alphabet.indexOf(upperChar);
      let codeChar = codage[index];
      resultat += isLower ? codeChar.toLowerCase() : codeChar;
    } else {
      resultat += char;
    }
  }

  document.getElementById("outputMessage").value = resultat;
}

function copier() {
  let output = document.getElementById("outputMessage");
  output.select();
  document.execCommand("copy");
  alert("Message copié !");
}
